package GuerraDeHormigas;

import java.awt.Color;
import java.awt.Image;
import java.awt.Point;
import entorno.Entorno;
import entorno.Herramientas;

public class Insecticida {

	Point centro;
	int diametro;
	Color color;
	Image mancha;
	
	Insecticida(int x, int y, int D){
		centro = new Point(x, y);
		this.diametro=D;
		this.color=Color.GREEN;
		mancha = Herramientas.cargarImagen("Imagenes/mancha.png");
	}
	
	public void dibujarInsecticida(Entorno entorno){
		entorno.dibujarCirculo(centro.x,centro.y,diametro,color);
		entorno.dibujarImagen(mancha, this.centro.x, this.centro.y, 0, (this.diametro*1.2)/75 );
	}
	
	public void estaTocandoTropa(Tropa[] tropas,double velNorm){
		for (int i=0;i<tropas.length;i++){
			if (tropas[i]!= null){
				int dx = this.centro.x - (int)tropas[i].x;
				int dy = this.centro.y - (int)tropas[i].y;
				int dist = (int) Math.sqrt(dx*dx+dy*dy);
				if (dist<this.diametro/2+tropas[i].diametro/2){
					tropas[i].infectada=true;
					tropas[i].velocidad=velNorm/2;
					}
				else{
					tropas[i].velocidad=velNorm;
				}
			}		
		}
	}
	
	public void estaTocandoHormiguero(Hormiguero[] hormiguero){
		for (int i=0;i<hormiguero.length;i++){
			int dx = this.centro.x - hormiguero[i].centro.x;
			int dy = this.centro.y - hormiguero[i].centro.y;
			int dist = (int) Math.sqrt(dx*dx+dy*dy);
			if (dist<this.diametro/2+hormiguero[i].diametro/2 && hormiguero[i].color!=Color.GRAY){
				hormiguero[i].infectada=true;
			}
		}		
	}
	
}
