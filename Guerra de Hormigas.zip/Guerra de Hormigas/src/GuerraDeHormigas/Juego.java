package GuerraDeHormigas;

import java.awt.Color;
import java.awt.Image;
import java.util.Random;
import entorno.Entorno;
import entorno.Herramientas;
import entorno.InterfaceJuego;

public class Juego extends InterfaceJuego{

	private Entorno entorno;
	Random random;
	Image Presentacion;
	Image Terreno;
	Image GanDelta;
	Image GanOmega;
	boolean blockRed=false;
	boolean blockBlue=false;
	boolean blockPresentacion=false;
	
	// hormigueros
	int cantHorm=8;
	int hormigasIni=96;
	Hormiguero[] hormigueros;
	int nivel=1;
	boolean infectada=false;
	int ticks=0;
	
	// tropas
	Tropa[] tropas;
	int cantTrop=10;
	int ticksTropa=0;
	double velInc=1;
	
	// variables de Insecticida
	Insecticida mancha;
	int ticksInsec=0;
	int timelife;
	int timedead;
	boolean llave=false;
	
	// variables de bandos
	Color omega = Color.RED;
	Color delta = Color.BLUE;
	Color neutral = Color.GRAY;
	
	int destAzul=7;
	int destRojo=7;
	int origAzul=0;
	int origRojo=0;
	
	Juego(){
		
		random = new Random();
		
		//prepara presentacion
		Presentacion = Herramientas.cargarImagen("Imagenes/Presentacion.png");
		
		//prepara terreno
		Terreno = Herramientas.cargarImagen("Imagenes/Terreno.png");
		
		//prepara cartel de ganador
		GanDelta = Herramientas.cargarImagen("Imagenes/Ganador Delta.png");
		GanOmega = Herramientas.cargarImagen("Imagenes/Ganador Omega.png");
		
		//tiempo del insecticida (vivo y muerto)
		this.timelife = random.nextInt(29000)+1000;
		this.timedead = random.nextInt(1000)+500;
		
		//Crea a las tropas
		tropas=new Tropa [cantTrop];
		//Crea los hormigueros
		hormigueros=new Hormiguero[cantHorm];
		//asigna posicion de hormigueros en forma aleatoria
		hormigueros[0] = new Hormiguero(random.nextInt(125)+100,random.nextInt(225)+100,random.nextInt(300)+50,nivel,neutral,infectada);
		hormigueros[1] = new Hormiguero(random.nextInt(200)+275,random.nextInt(225)+100,hormigasIni,nivel,delta,infectada);
		hormigueros[2] = new Hormiguero(random.nextInt(200)+525,random.nextInt(225)+100,random.nextInt(300)+50,nivel,neutral,infectada);
		hormigueros[3] = new Hormiguero(random.nextInt(125)+775,random.nextInt(225)+100,hormigasIni,nivel,delta,infectada);
		hormigueros[4] = new Hormiguero(random.nextInt(125)+100,random.nextInt(225)+375,hormigasIni,nivel,omega,infectada);
		hormigueros[5] = new Hormiguero(random.nextInt(200)+275,random.nextInt(225)+375,random.nextInt(300)+50,nivel,neutral,infectada);
		hormigueros[6] = new Hormiguero(random.nextInt(200)+525,random.nextInt(225)+375,hormigasIni,nivel,omega,infectada);
		hormigueros[7] = new Hormiguero(random.nextInt(125)+775,random.nextInt(225)+375,random.nextInt(300)+50,nivel,neutral,infectada);
			
		entorno = new Entorno(this, "Guerra de Hormigas - Version 0.01", 1000, 700);	
		entorno.iniciar();

	}
	
	public void tick(){
		
		//Muestra el terreno
		entorno.dibujarImagen(Terreno, 500, 355, 0, 1);
		
//------------------ Origen - Destino ---------------------------------------------------------		

		//Actualiza los origenes del hormiguero (azul-rojo).
		
		int [] arrAzul;
		int contAzul=0;
		for (int i=0; i<this.cantHorm;i++){
			if (hormigueros[i].color==Color.BLUE)
				contAzul++;
		}
		arrAzul = new int [contAzul];
		int indice=0;
		for (int i=0; i<this.cantHorm;i++){
			if (hormigueros[i].color==Color.BLUE){
				arrAzul[indice]=i;
				indice++;
			}
		}
		
		int [] arrRojo;
		int contRojo=0;
		for (int i=0; i<this.cantHorm;i++){
			if (hormigueros[i].color==Color.RED)
				contRojo++;
		}
		arrRojo = new int [contRojo];
		int indicador=0;
		for (int i=0; i<this.cantHorm;i++){
			if (hormigueros[i].color==Color.RED){
				arrRojo[indicador]=i;
				indicador++;
			}
		}
		
		//Si algun hormiguero es conquistado posiciona el origen donde corresponda (inicialmente 0).
		
		if (origAzul>=contAzul)
			origAzul=0;
		if (origRojo>=contRojo)
			origRojo=0;
		
		//Dibujar etiquetas de origen destino si es que hay hormigueros
		
		if (arrAzul.length!=0){
			hormigueros[destAzul].dibujarDestAzul(entorno);
			hormigueros[arrAzul[origAzul]].dibujarOrigAzul(entorno);
		}
		if (arrRojo.length!=0){
			hormigueros[destRojo].dibujarDestRojo(entorno);
			hormigueros[arrRojo[origRojo]].dibujarOrigRojo(entorno);
		}
		
//------------------Hormigueros-------------------------------------------------------------------		
		
		//Dibuja los hormigueros y sus datos
		for (int i=0; i<this.cantHorm;i++){
				if (hormigueros[i]!=null)
					hormigueros[i].dibujarHormiguero(entorno);
					hormigueros[i].mostrarDatos(entorno);
		}
		
		//Evaluacion de cantidad de hormigas en cada hormiguero
		//y asignacion de nivel segun corresponda
		for (int i=0; i<this.cantHorm;i++){
				hormigueros[i].asigNivel(entorno);
		}
		
		//Produccion de hormigas segun Nivel
		if (ticks>=500){
			for (int i=0; i<this.cantHorm;i++){
				hormigueros[i].prodHormigas(entorno);
			}
			this.ticks=0;
		}
		this.ticks++;
		
		//Si algun Hormiguero se queda sin hormigas, se pone neutral
		for (int i=0; i<this.cantHorm;i++){
			if (hormigueros[i].CantHorm==0){
				hormigueros[i].color=Color.gray;
			}
		}
		
		//Infeccion en cadena - Si algun Hormiguero esta infectado tambien afecta a los de su nivel inferior
		for (int i=0; i<this.cantHorm;i++){
			if (hormigueros[i].infectada==true){
				hormigueros[i].infecCadena(hormigueros);
			}
		}

//------------------Insecticida------------------------------------------------------------------

		//Produce una mancha de insecticida en forma aleatoria. 

			//Tiempo con vida
			if (llave){
				if (ticksInsec>=timelife){
					this.timelife = random.nextInt(29000)+1000;
					this.ticksInsec=0;
					llave=false;
					mancha=null;
				}
				this.ticksInsec++;
			}
			
			// tiempo muerto
			if (llave!=true){
				if (ticksInsec>=timedead){
					this.timelife = random.nextInt(1000)+500;
					this.ticksInsec=0;
					llave=true;
					mancha = new Insecticida(random.nextInt(800)+100,random.nextInt(500)+100,random.nextInt(50)+25);
				}
				this.ticksInsec++;
			}
		
		//Dibuja las manchas de insecticida
		if (mancha!=null){
			mancha.dibujarInsecticida(entorno);
		}
		
		//Evalua si el insecticida toca a alguna tropa.
		if (mancha!=null){
			mancha.estaTocandoTropa(tropas,velInc);
		}else{
			for (int i=0; i<this.cantTrop;i++){
				if (tropas[i]!=null){
					tropas[i].velocidad=velInc;
				}
			}
		}
		
		//Evalua si el insecticida toca a alguna hormiguero.
		if (mancha!=null){
			mancha.estaTocandoHormiguero(hormigueros);
		}else{
			for (int i=0; i<this.cantHorm;i++){
				hormigueros[i].infectada=false;
			}
		}					
		
//-------------------- Tropas -------------------------------------------------------------------		
		
		//Mueve a las tropas
		for (int i=0; i<this.cantTrop;i++){
			if (tropas[i]!=null){
				tropas[i].mueveTropa(entorno);
				}
		}
		
		//Dibuja a las tropas
		for (int i=0; i<this.cantTrop;i++){
			if (tropas[i]!=null)
				tropas[i].dibujarTropa(entorno);
		}
		
		//Evalua si alguna tropa llego a su destino, y si lo hace procede a atacar o a sumarse.
		for (int i=0; i<this.cantTrop;i++){
			if (tropas[i]!=null){
				if(tropas[i].llegaTropa(entorno)){
					tropas[i].atacaOsuma(hormigueros);
					tropas[i]=null;
				}
			}
		}
		
		//cada ciertos ticks evalua si alguna tropa esta infectada y va decrementando su tropa.
		if (ticksTropa>=25){
			for (int i=0; i<this.cantTrop;i++){
				if (tropas[i]!=null){
					tropas[i].decrSoldTropa(entorno);
					if (tropas[i].Soldados<=0)
						tropas[i]=null;
				}
			}
			this.ticksTropa=0;
		}
		this.ticksTropa++;
		
//--------------- Evaluacion de consola -------------------------------------------------------------------------------
		
		//------Jugador Delta------
		
		//destino
		if (arrAzul.length!=0){
			if (entorno.estaPresionada('W'))
				if (destAzul<7)
					destAzul++;
					if (destAzul==arrAzul[origAzul])
						if (arrAzul[origAzul]==cantHorm-1)
							destAzul--;
						else
							destAzul++;
			if (entorno.estaPresionada('S'))
				if (destAzul>0)
					destAzul--;
					if (destAzul==arrAzul[origAzul])
						if (arrAzul[origAzul]==0)
							destAzul++;
						else
							destAzul--;
		}
		
		//origen		
		if (entorno.estaPresionada('D'))
			if (origAzul<arrAzul.length-1)
				origAzul++;
		if (entorno.estaPresionada('A'))
			if (origAzul>0)
				origAzul--;

		//envio de tropas 		
		if (entorno.estaPresionada('1')||entorno.estaPresionada('2')||entorno.estaPresionada('3')){
			int i=0;
			boolean seguir=true;
			while (seguir && i<this.cantTrop){
				if (arrAzul.length!=0){
					if (tropas[i]==null && hormigueros[arrAzul[origAzul]].CantHorm>=3){
						seguir=false;
	
						double dy=delta(hormigueros[arrAzul[origAzul]].centro.y,hormigueros[destAzul].centro.y);
						double dx=delta(hormigueros[destAzul].centro.x,hormigueros[arrAzul[origAzul]].centro.x);
						double angRad=-Math.atan2(dy,dx);
	
						int cantHormigas=0;
						if (entorno.estaPresionada('1')){
							cantHormigas=(hormigueros[arrAzul[origAzul]].CantHorm)/3;
							hormigueros[arrAzul[origAzul]].CantHorm=(hormigueros[arrAzul[origAzul]].CantHorm)-cantHormigas;
						}
						if (entorno.estaPresionada('2')){
							cantHormigas=(hormigueros[arrAzul[origAzul]].CantHorm*2)/3;
							hormigueros[arrAzul[origAzul]].CantHorm=(hormigueros[arrAzul[origAzul]].CantHorm)-cantHormigas;	
						}
						if (entorno.estaPresionada('3')){	
							cantHormigas=hormigueros[arrAzul[origAzul]].CantHorm;
							hormigueros[arrAzul[origAzul]].CantHorm=0;
						}
						int dX = (hormigueros[destAzul].centro.x)-(hormigueros[arrAzul[origAzul]].centro.x);
						boolean InfAzul;
						if (hormigueros[arrAzul[origAzul]].infectada==true)
							InfAzul=true;
						else
							InfAzul=false;
						tropas[i] = new Tropa(hormigueros[arrAzul[origAzul]].centro.x, hormigueros[arrAzul[origAzul]].centro.y, angRad, velInc ,Color.BLUE, InfAzul, hormigueros[destAzul].centro.x, hormigueros[destAzul].color, destAzul, dX, cantHormigas);
						Herramientas.play("tropaAzul.wav");
					}
				}
				i++;	
			}
		}
		
		//------Jugador Omega------
				
		//destino
		if (arrRojo.length!=0){
			if (entorno.estaPresionada(entorno.TECLA_ARRIBA))
				if (destRojo<7)
					destRojo++;
					if (destRojo==arrRojo[origRojo])
						if (arrRojo[origRojo]==cantHorm-1)
							destRojo--;
						else
							destRojo++;
			if (entorno.estaPresionada(entorno.TECLA_ABAJO))
				if (destRojo>0)
					destRojo--;
					if (destRojo==arrRojo[origRojo])
						if (arrRojo[origRojo]==0)
							destRojo++;
						else
							destRojo--;
		}
		
		//origen
		if (entorno.estaPresionada(entorno.TECLA_DERECHA))
			if (origRojo<arrRojo.length-1)
				origRojo++;
		boolean tropDisp=true;
		int j=0;
		while (tropDisp && j<this.cantTrop){
			if (tropas[j]==null){
				tropDisp=false;
			}
			j++;
		}if (entorno.estaPresionada(entorno.TECLA_IZQUIERDA))
			if (origRojo>0)
				origRojo--;
		
		//envio de tropas 	
		if (entorno.estaPresionada('7')||entorno.estaPresionada('8')||entorno.estaPresionada('9')){
			int i=0;
			boolean seguir=true;
			while (seguir && i<this.cantTrop){
				if (arrRojo.length!=0){
					if (tropas[i]==null && hormigueros[arrRojo[origRojo]].CantHorm>=3){
						seguir=false;
						
						double dy=delta(hormigueros[arrRojo[origRojo]].centro.y,hormigueros[destRojo].centro.y);
						double dx=delta(hormigueros[destRojo].centro.x,hormigueros[arrRojo[origRojo]].centro.x);
						double angRad=-Math.atan2(dy,dx);
						
						int cantHormigas=0;
						if (entorno.estaPresionada('7')){
							cantHormigas=(hormigueros[arrRojo[origRojo]].CantHorm)/3;
							hormigueros[arrRojo[origRojo]].CantHorm=(hormigueros[arrRojo[origRojo]].CantHorm)-cantHormigas;
						}
						if (entorno.estaPresionada('8')){
							cantHormigas=(hormigueros[arrRojo[origRojo]].CantHorm*2)/3;
							hormigueros[arrRojo[origRojo]].CantHorm=(hormigueros[arrRojo[origRojo]].CantHorm)-cantHormigas;	
						}
						if (entorno.estaPresionada('9')){	
							cantHormigas=hormigueros[arrRojo[origRojo]].CantHorm;
							hormigueros[arrRojo[origRojo]].CantHorm=0;
						}
						int dX = (hormigueros[destRojo].centro.x)-(hormigueros[arrRojo[origRojo]].centro.x);
						boolean InfRojo;
						if (hormigueros[arrRojo[origRojo]].infectada==true)
							InfRojo=true;
						else
							InfRojo=false;
						tropas[i] = new Tropa(hormigueros[arrRojo[origRojo]].centro.x, hormigueros[arrRojo[origRojo]].centro.y, angRad, velInc ,Color.RED, InfRojo, hormigueros[destRojo].centro.x, hormigueros[destRojo].color, destRojo, dX, cantHormigas);
						Herramientas.play("tropaRojo.wav");
					}
				}
				i++;		
			}
		}
		
//--------------- Presentacion -------------------------------------------------------------------------------
		
		if (this.blockPresentacion==false){
			entorno.dibujarImagen(Presentacion, 505, 350, 0, 1);
		}
		
		if (entorno.estaPresionada(entorno.TECLA_ENTER)){
			this.blockPresentacion=true;
		}
		
//--------------- Evaluacion del Juego ------------------------------------------------------------
		
		//Evaluar si hay tropas azules y rojas	
		boolean hayAzul=false;
		boolean hayRojo=false;
		for (int i=0; i<this.cantTrop;i++){
			if (tropas[i]!=null){
				if (tropas[i].color==Color.BLUE){
					hayAzul=true;
				}
				if (tropas[i].color==Color.RED){
					hayRojo=true;
				}
			}
		}
		
		if (arrAzul.length==0 && blockRed==false && hayAzul==false){
			entorno.dibujarImagen(GanOmega, 500, 350, 0, 1);
			blockBlue=true;
		}
		if (arrRojo.length==0 && blockBlue==false && hayRojo==false){
			entorno.dibujarImagen(GanDelta, 500, 350, 0, 1);
			blockRed=true;
		}
				
		
	}
	
	
	
	public static double delta(int dest, int orig) {
		if (dest>orig){
			return dest-orig;
		}else{
			return -1.0*(orig-dest);
		}
	}
	
	@SuppressWarnings("unused")
	public static void main(String[] args)
	{		
		Juego juego = new Juego();
	}

}
