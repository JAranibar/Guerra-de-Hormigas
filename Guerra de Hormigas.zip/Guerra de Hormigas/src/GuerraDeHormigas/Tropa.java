package GuerraDeHormigas;

import java.awt.Color;
import java.awt.Image;
import entorno.Entorno;
import entorno.Herramientas;

public class Tropa {

	double x;
	double y;
	int diametro;
	Color color;
	double velocidad;
	boolean infectada;
	double angulo;
	int limite;
	Color colDest;
	int Homgnum;
	int cuadrante;
	int Soldados;
	Image tropInf;
	
	Tropa(int x, int y, double A, double V ,Color C, boolean I, int L, Color CL, int NH, int Cuadra, int S){
		this.x=x;
		this.y=y;
		this.angulo=A;
		this.diametro=23;
		this.color=C;
		this.velocidad=V;
		this.infectada=I;
		this.limite=L;
		this.colDest=CL;
		this.Homgnum=NH;
		this.cuadrante=Cuadra;
		this.Soldados=S;
		
		tropInf = Herramientas.cargarImagen("Imagenes/tropaInf.png");
	}
	
	public void dibujarTropa(Entorno entorno){		
		entorno.dibujarCirculo(this.x,this.y,diametro,this.color);
		entorno.cambiarFont(""+this.Soldados, 9, Color.YELLOW);
		entorno.escribirTexto(""+this.Soldados, this.x-7, this.y+4);
		if (this.infectada==true){
			entorno.dibujarImagen(tropInf, this.x, this.y, 0, 0.5);
		}
	}
	
	public void mueveTropa(Entorno entorno){
		this.x+=Math.cos(this.angulo)*this.velocidad;
		this.y+=Math.sin(this.angulo)*this.velocidad;
	}
	
	public boolean llegaTropa(Entorno entorno){
		if (this.cuadrante>0){
			if (this.x>this.limite)
				return true;
			return false;
		}else{
			if (this.x<this.limite)
				return true;
			return false;
		}
	}
	
	public void atacaOsuma(Hormiguero[] hormiguero){
		if (hormiguero[this.Homgnum].color==Color.GRAY){
			if (this.color==Color.BLUE){
				int difSol=hormiguero[this.Homgnum].CantHorm-this.Soldados;
				if (difSol>=0){
					hormiguero[this.Homgnum].CantHorm=difSol;
				}else{
					hormiguero[this.Homgnum].CantHorm=difSol*(-1);
					hormiguero[this.Homgnum].color=Color.BLUE;
				}
			}else{
				int difSol=hormiguero[this.Homgnum].CantHorm-this.Soldados;
				if (difSol>=0){
					hormiguero[this.Homgnum].CantHorm=difSol;
				}else{
					hormiguero[this.Homgnum].CantHorm=difSol*(-1);
					hormiguero[this.Homgnum].color=Color.RED;
				}
			}
		}else{
			if(hormiguero[this.Homgnum].color==Color.BLUE){
				if (this.color==Color.BLUE){
					hormiguero[this.Homgnum].CantHorm=hormiguero[this.Homgnum].CantHorm+this.Soldados;
				}else{
					int difSol=hormiguero[this.Homgnum].CantHorm-this.Soldados;
					if (difSol>=0){
						hormiguero[this.Homgnum].CantHorm=difSol;
					}else{
						hormiguero[this.Homgnum].CantHorm=difSol*(-1);
						hormiguero[this.Homgnum].color=Color.RED;
					}
				}
			}else{
				if (this.color==Color.RED){
					hormiguero[this.Homgnum].CantHorm=hormiguero[this.Homgnum].CantHorm+this.Soldados;
				}else{
					int difSol=hormiguero[this.Homgnum].CantHorm-this.Soldados;
					if (difSol>=0){
						hormiguero[this.Homgnum].CantHorm=difSol;
					}else{
						hormiguero[this.Homgnum].CantHorm=difSol*(-1);
						hormiguero[this.Homgnum].color=Color.BLUE;
					}
				}
			}
		}
	}
	
	public void decrSoldTropa(Entorno entorno){
		if(this.infectada==true){
			this.Soldados=this.Soldados-1;
		}
	}

}
