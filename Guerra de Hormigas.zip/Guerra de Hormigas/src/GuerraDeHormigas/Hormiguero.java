package GuerraDeHormigas;

import java.awt.Color;
import java.awt.Point;
import entorno.Entorno;
import java.awt.Image;
import entorno.Herramientas;

public class Hormiguero {

	Point centro;
	int diametro;
	Color color;
	int CantHorm;
	int nivel;
	Boolean infectada;
	Image hormOmega;
	Image hormDelta;
	Image hormNeutral;
	Image destAzul;
	Image destRojo;
	Image origAzul;
	Image origRojo;
	Image infecta;
	
	Hormiguero(int x, int y, int H, int N, Color C, boolean I){
		centro =new Point (x,y);
		this.diametro=40;
		this.color=C;	
		this.CantHorm=H;
		this.nivel=N;
		this.infectada=I;
		
		hormDelta = Herramientas.cargarImagen("Imagenes/hormiguero delta.png");
		hormOmega = Herramientas.cargarImagen("Imagenes/hormiguero omega.png");
		hormNeutral = Herramientas.cargarImagen("Imagenes/hormiguero neutral.png");
		
		destAzul = Herramientas.cargarImagen("Imagenes/destino azul.png");
		destRojo = Herramientas.cargarImagen("Imagenes/destino rojo.png");
		origAzul = Herramientas.cargarImagen("Imagenes/origen azul.png");
		origRojo = Herramientas.cargarImagen("Imagenes/origen rojo.png");
		infecta = Herramientas.cargarImagen("Imagenes/infecta.png");
	}
	
	public void dibujarHormiguero(Entorno entorno){
		entorno.dibujarCirculo(centro.x,centro.y,diametro,color);
		if (color==Color.RED)
			entorno.dibujarImagen(hormOmega, this.centro.x, this.centro.y, 0, 0.5);
		if (color==Color.BLUE)
			entorno.dibujarImagen(hormDelta, this.centro.x, this.centro.y, 0, 0.5);
		if (color==Color.GRAY)
			entorno.dibujarImagen(hormNeutral, this.centro.x, this.centro.y, 0, 0.5);
		if (this.infectada==true)
			entorno.dibujarImagen(infecta, this.centro.x, this.centro.y-18, 0, 0.5);
	}
	
	public void mostrarDatos(Entorno entorno){
		String texto="Cant. Homg: ";
		entorno.cambiarFont(texto+this.CantHorm, 12, this.color);
		entorno.escribirTexto(texto+this.CantHorm, this.centro.x-25, this.centro.y-50);
		String nivel="Nivel: ";
		entorno.cambiarFont(nivel+this.nivel, 12, this.color);
		entorno.escribirTexto(nivel+this.nivel, this.centro.x-25, this.centro.y-30);
	}
	
	public void asigNivel(Entorno entorno){
		if (this.CantHorm<40)
			this.nivel=1;
		if (this.CantHorm>=40 && this.CantHorm<100)
			this.nivel=2;
		if (this.CantHorm>=100 && this.CantHorm<300)
			this.nivel=3;
		if (this.CantHorm>=300)
			this.nivel=4;
	}
	
	public void prodHormigas(Entorno entorno){
		if (this.nivel==1 && this.infectada==false && this.color!=Color.GRAY)
			this.CantHorm++;
		if (this.nivel==2 && this.infectada==false && this.color!=Color.GRAY)
			this.CantHorm=this.CantHorm+2;
		if (this.nivel==3 && this.infectada==false && this.color!=Color.GRAY)
			this.CantHorm=this.CantHorm+4;
		if (this.nivel==4 && this.infectada==false && this.color!=Color.GRAY)
			this.CantHorm=this.CantHorm+8;
	}
	
	public void dibujarDestAzul(Entorno entorno){
		entorno.dibujarImagen(destAzul, this.centro.x+55, this.centro.y-25, 0);
	}
	
	public void dibujarDestRojo(Entorno entorno){
		entorno.dibujarImagen(destRojo, this.centro.x+55, this.centro.y-10, 0);
	}
	
	public void dibujarOrigAzul(Entorno entorno){
		entorno.dibujarImagen(origAzul, this.centro.x+55, this.centro.y+5, 0);
	}
	
	public void dibujarOrigRojo(Entorno entorno){
		entorno.dibujarImagen(origRojo, this.centro.x+55, this.centro.y+5, 0);
	}
	
	public void infecCadena(Hormiguero[] hormigueros){
		for (int i=0;i<hormigueros.length;i++){
			if (hormigueros[i].color==this.color && hormigueros[i].infectada==false && hormigueros[i].nivel<this.nivel){
				hormigueros[i].infectada=true;
			}
		}
	}
	
}
